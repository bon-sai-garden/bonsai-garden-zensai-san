# Integrity first, by hand

This package carries no executable file. Its check is code you can read below, before it runs. It needs only what the room already has: a shell, Python 3 (3.9 or later), and one download of the public key that sealed it. Nothing is installed. The check sends nothing about the person or this conversation; its only request out is that download, which, like any download, shows its server this room's address. Where this room's shell cannot download at all, the key reaches block 2 by hand instead: the same key, read as text from the same address and written to a file beside this package's folder; the block reads that file as bytes, runs nothing from it, and makes no request out. Block 2 says how.

Run the two blocks below in order, from this package's base directory: the folder that holds `SKILL.md` and `MANIFEST.json`. Copy each block exactly as it stands. Take every verdict from what a block prints, never from reading a file yourself.

**Anything but two `ok` lines means stop**, with one held answer: `2 given-ok`, which block 2 prints when its key was given by hand as that block says; it is a go, and it carries a debt, named there. Stop at the first block that does not print `ok`: never run block 2 after block 1 failed. Use nothing in this package, and tell the person which block failed or could not run, and exactly what it printed. No shell, no Python, no answer from the key's address and no key given by hand: each is a check that could not run, and a stop, never a pass.

## 1. Every file is the one that was sealed

`MANIFEST.json` names every file with its sha256. Each must match, `SKILL.md` too, byte for byte, its frontmatter and description included. None may be missing, and nothing may be there that it does not name. The manifest itself must be the file its seal, `.MANIFEST.json.bonsaisig`, was made over: its blake2b-512 equals the seal's `file-hash`. Every name is printed quoted, so nothing in the package can add a line to the verdict.

```bash
python3 -I - <<'EOF'
import hashlib, json, os, re
slug = "zensai-san"
try:
    m = json.load(open("MANIFEST.json", encoding="utf-8"))
    s = json.load(open(".MANIFEST.json.bonsaisig", encoding="utf-8"))
except Exception as e:
    print(f"1 could not run: {type(e).__name__}: {str(e)!r}")
    raise SystemExit(1)
bad = []
if m.get("slug") != slug:
    bad.append(f"the manifest names {m.get('slug')!r}, not {slug!r}")
if m.get("algorithm") != "sha256":
    bad.append(f"the manifest's algorithm is {m.get('algorithm')!r}, not 'sha256'")
want = {}
for k, v in (m.get("files") or {}).items():
    if k.startswith(slug + "/"):
        want[k[len(slug) + 1 :]] = v
    else:
        bad.append(f"outside the package: {k!r}")
seen = set()
for d, dirs, files in os.walk("."):
    for n in sorted(dirs + files):
        f = os.path.relpath(os.path.join(d, n)).replace(os.sep, "/")
        if os.path.islink(f):
            bad.append(f"a link: {f!r}")
            continue
        if n not in files or f in ("MANIFEST.json", ".MANIFEST.json.bonsaisig"):
            continue
        seen.add(f)
        if f not in want:
            bad.append(f"not in the manifest: {f!r}")
            continue
        if hashlib.sha256(open(f, "rb").read()).hexdigest() != want[f]:
            bad.append(f"changed: {f!r}")
bad += [f"missing: {f!r}" for f in sorted(set(want) - seen)]
named = re.search(r"^name:\s*[\"']?([^\"'\n]+?)[\"']?\s*$", open("SKILL.md", encoding="utf-8").read(), re.M)
if not named or named.group(1) != slug:
    bad.append(f"SKILL.md does not name {slug!r}")
if hashlib.blake2b(open("MANIFEST.json", "rb").read(), digest_size=64).hexdigest() != s.get("file-hash"):
    bad.append("MANIFEST.json is not the file its seal was made over")
for k, v in (
    ("format", "bonsaisig/2"),
    ("target", "MANIFEST.json"),
    ("signer", "zensai-san"),
    ("role", "owner"),
    ("fingerprint", "038019e65abdc0279870941e6ed942ae"),
):
    if s.get(k) != v:
        bad.append(f"the seal's {k} is {s.get(k)!r}, not {v!r}")
if bad:
    print("1 FAILED: " + "; ".join(bad))
    raise SystemExit(1)
print(f"1 ok: {len(want)} files match the sealed manifest")
EOF
```

## 2. The sealing key vouches for the seal

The key is fetched from where it is published, never taken from this package: <https://bon-sai.garden/keys/038019e65abdc0279870941e6ed942ae.bin>. Its fingerprint, the first 32 hex of its sha256, must be `038019e65abdc0279870941e6ed942ae`. The seal's signature must verify under it. The verifier is the code below: Ed25519 as RFC 8032 writes it, in Python's own integers, nothing imported beyond the standard library, no program started, nothing installed. It refuses a scalar at or above the group order, a key or nonce that is not canonically encoded or not on the curve, and a key or nonce of small order. A no is final. The signature covers `bonsai-seal-v2` and a newline, followed by every field of the seal but `signature` as canonical JSON: keys sorted, no whitespace, UTF-8 kept.

**Where this room's shell cannot reach that address**, the block prints `2 could not run` and names it; a room may also forbid a download from its shell before the block runs. The same key is published as text at <https://bon-sai.garden/keys/038019e65abdc0279870941e6ed942ae.hex>: 64 hex characters, nothing else. Read them with whatever reaches the web from where you sit (a browser; a fetch tool that returns text), and write exactly what it returned to the file `zensai-san-public-key.hex` beside this package's folder, in the folder that holds it, never inside it (block 1 would name a file the manifest does not); the stop line prints that file's full path. Then run the block again, unchanged. It reads the file as bytes and runs nothing from it: the only thing it takes is exactly 64 hex characters with nothing but whitespace around them, and anything else is refused, named by the file and never printed. The fingerprint check then binds the key whatever carried it: a key that is not the one with the fingerprint above fails. No request goes out. The verdict is `2 given-ok`, never `ok`, and it carries one debt: the block did not reach the key's published address, so it cannot say that the key still stands there. The second witness, at the end of this page, is then not a courtesy but yours to do, and the line names its address. The file holds only a public key as text; it may stay or go, and while it stays the block takes it before the address. So a key file you did not write, or a `given-ok` in a room whose shell reaches the address, means someone else put it there: remove it and run the block again. At that path the block takes a plain file or nothing: a link, a folder, a pipe or a device there is a finding, and the block stops naming it, reads nothing from it and asks for nothing to be written there; a file larger than 4096 bytes is refused by its size before it is read. Nothing on this page is yours to edit: a block that differs from this page is a finding.

```bash
python3 -I - <<'EOF'
import base64, hashlib, json, os, urllib.request
KEY_FILE = os.path.join("..", "zensai-san-public-key.hex")  # the key as text, written by hand beside this package's folder, never inside it
try:
    s = json.load(open(".MANIFEST.json.bonsaisig", encoding="utf-8"))
    sig = base64.b64decode(s["signature"], validate=True)
except Exception as e:
    print(f"2 could not run: {type(e).__name__}: {str(e)!r}")
    raise SystemExit(1)
where = os.path.abspath(KEY_FILE)
if os.path.lexists(KEY_FILE) and (os.path.islink(KEY_FILE) or not os.path.isfile(KEY_FILE)):
    print(f"2 could not run: something that is not a plain file is already at {where!r} (a link, a folder, a pipe or a device). This block read nothing from it, and the key does not go there: the page never asked for it, so it is a finding; look at what it is and who put it there, and once it is gone, run this block again, unchanged")
    raise SystemExit(1)
given = os.path.isfile(KEY_FILE)
if given:
    try:
        size = os.path.getsize(KEY_FILE)
        if size > 4096:
            print(f"2 could not run: the key file {where!r} is {size} bytes, not the key's 64 hex characters: nothing of it was read; write there exactly what https://bon-sai.garden/keys/038019e65abdc0279870941e6ed942ae.hex returns, and nothing else")
            raise SystemExit(1)
        text = open(KEY_FILE, "rb").read().strip()
    except Exception as e:
        print(f"2 could not run: the key file {where!r} could not be read ({type(e).__name__}: {str(e)!r})")
        raise SystemExit(1)
    if len(text) != 64 or not all(c in b"0123456789abcdefABCDEF" for c in text):
        print(f"2 could not run: the key file {where!r} does not hold the key's 64 hex characters and nothing else ({len(text)} bytes once the whitespace around them is dropped): write there exactly what https://bon-sai.garden/keys/038019e65abdc0279870941e6ed942ae.hex returns")
        raise SystemExit(1)
    key = bytes.fromhex(text.decode("ascii"))
else:
    try:
        req = urllib.request.Request("https://bon-sai.garden/keys/038019e65abdc0279870941e6ed942ae.bin", headers={"User-Agent": "bonsai-garden-integrity"})
        key = urllib.request.urlopen(req, timeout=30).read()
    except Exception as e:
        print(f"2 could not run: the key's address was not reached from this room ({type(e).__name__}: {str(e)!r}). Read the same key as text at https://bon-sai.garden/keys/038019e65abdc0279870941e6ed942ae.hex with whatever reaches the web from where you sit, write exactly what it returns to the file {where!r} (beside this package's folder, never inside it), and run this block again, unchanged")
        raise SystemExit(1)
fp = hashlib.sha256(key).hexdigest()[:32]
bad = []
if len(key) != 32:
    bad.append(f"the key is {len(key)} bytes, not 32")
if fp != "038019e65abdc0279870941e6ed942ae":
    bad.append(f"the key's fingerprint is {fp!r}, not '038019e65abdc0279870941e6ed942ae'")
if bad:
    print("2 FAILED: " + "; ".join(bad))
    raise SystemExit(1)
payload = (
    "bonsai-seal-v2\n"
    + json.dumps({k: v for k, v in s.items() if k != "signature"}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
).encode("utf-8")

# Ed25519, verify only, as RFC 8032 writes it (section 5.1), in Python's own integers. No secret is ever here.
p = 2**255 - 19  # the field
d = -121665 * pow(121666, p - 2, p) % p  # the curve: -x^2 + y^2 = 1 + d x^2 y^2
L = 2**252 + 27742317777372353535851937790883648493  # the order of the base point B
ONE = (0, 1, 1, 0)  # the identity, in extended coordinates (X, Y, Z, T)

def decode_point(b):
    """Section 5.1.3: 32 bytes to a point, or None wherever the RFC says decoding fails."""
    y = int.from_bytes(b, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= p:  # refused: not canonically encoded (a y at or above p)
        return None
    x2 = (y * y - 1) * pow(d * y * y + 1, p - 2, p) % p
    x = pow(x2, (p + 3) // 8, p)
    if (x * x - x2) % p:
        x = x * pow(2, (p - 1) // 4, p) % p
    if (x * x - x2) % p:  # refused: not on the curve (x^2 has no square root)
        return None
    if x == 0 and sign:  # refused: x = 0 with the sign bit set
        return None
    if x & 1 != sign:
        x = p - x
    return (x, y, 1, x * y % p)

def point_add(P, Q):
    """Section 5.1.4: the addition law in extended coordinates."""
    A, B_ = (P[1] - P[0]) * (Q[1] - Q[0]) % p, (P[1] + P[0]) * (Q[1] + Q[0]) % p
    C, D = 2 * P[3] * Q[3] * d % p, 2 * P[2] * Q[2] % p
    E, F, G, H = B_ - A, D - C, D + C, B_ + A
    return (E * F % p, G * H % p, F * G % p, E * H % p)

def scalar_mul(k, P):
    """k times P, by doubling and adding, k read from its lowest bit up."""
    Q = ONE
    while k:
        if k & 1:
            Q = point_add(Q, P)
        P, k = point_add(P, P), k >> 1
    return Q

def same_point(P, Q):
    """Both coordinates compared, in projective form: X1 Z2 = X2 Z1 and Y1 Z2 = Y2 Z1."""
    return (P[0] * Q[2] - Q[0] * P[2]) % p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % p == 0

def small_order(P):
    """8 P is the identity: a point of the torsion subgroup, under which a signature could be forged."""
    return same_point(scalar_mul(8, P), ONE)

B = decode_point((4 * pow(5, p - 2, p) % p).to_bytes(32, "little"))  # the base point: y = 4/5, x even

def verify(key, msg, sig):
    """Section 5.1.7, cofactorless: s B == R + h A, with h = SHA-512(R || A || msg) mod L. A no is final."""
    if len(key) != 32 or len(sig) != 64:  # refused: a key or signature of the wrong length, before anything is decoded
        return False
    A, R, s = decode_point(key), decode_point(sig[:32]), int.from_bytes(sig[32:], "little")
    if A is None or R is None:  # refused: a key or nonce that does not decode
        return False
    if s >= L:  # refused: a scalar at or above the group order
        return False
    if small_order(A) or small_order(R):  # refused: a key or nonce of small order
        return False
    h = int.from_bytes(hashlib.sha512(sig[:32] + key + msg).digest(), "little") % L
    return same_point(scalar_mul(s, B), point_add(R, scalar_mul(h, A)))

ok = verify(key, payload, sig)
how = f", the key given by hand (read from {where!r}): this block did not reach the key's published address, so compare the fingerprint yourself at https://bon-sai.garden/verify/?fp={fp}" if given else ""
print(f"2 {'given-ok' if given else 'ok'}: sealed by zensai-san as owner, key {fp}{how}" if ok else "2 FAILED: the signature does not verify under that key")
raise SystemExit(0 if ok else 1)
EOF
```

## When both say ok

Say nothing about it, and go on. A check is spoken of only when it fails. `2 given-ok` is the one exception: it passed, and it says so in one plain line, never as an alarm, naming the debt it carries, that the key reached the check by hand and the second witness below is the person's to do, at the address the line names.

What the check proves: these files are intact, and sealed by the key with the fingerprint above. It tells you that, not who made this copy. Anyone can re-seal a copy with a key of their own and rewrite this page to match. So the second witness stands outside the package: anyone can compare `038019e65abdc0279870941e6ed942ae` with the garden's own record, in their own browser, at <https://bon-sai.garden/verify/?fp=038019e65abdc0279870941e6ed942ae>.
