# Integrity first, by hand

This package carries no executable file. Its check is code you can read below, before it runs. It needs only what the room already has: a shell and Python 3 (3.9 or later). Nothing is installed, and nothing goes out: the check makes no request, to any address, and sends nothing about the person or this conversation. The key it checks against is the one this package carries, `identity/zensai-san-public-key.bin`, held to the fingerprint this page pins, `038019e65abdc0279870941e6ed942ae`. A new key for zensai-san would be a new release of this package, never a change to one already installed.

Run the two blocks below in order, from this package's base directory: the folder that holds `SKILL.md` and `MANIFEST.json`, where the package is installed. If this room must copy the package first, copy it whole, hidden files included: `cp -a <dir>/. <dest>`. A `cp -R <dir>/*` drops every name that begins with a dot, and block 1 then stops on the missing seal. Do not look for the files with a listing tool first: some hide names that begin with a dot. The blocks open the files themselves. Copy each block exactly as it stands. Take every verdict from what a block prints, never from reading a file yourself.

**Anything but `1 ok` and `2 ok` means stop.** Stop at the first block that does not print `ok`: never run block 2 after block 1 failed. Use nothing in this package, and tell the person which block failed or could not run, and exactly what it printed. No shell and no Python are each a check that could not run, and a stop, never a pass.

## 1. Every file is the one that was sealed

`MANIFEST.json` names every file with its sha256. Each must match, `SKILL.md` too, byte for byte, its frontmatter and description included. None may be missing, and nothing may be there that it does not name; a file the room itself dropped into the folder (`.DS_Store` after a Finder visit) is still not in the manifest: remove it and run the block again. Every entry must be a plain file: a link, a folder in a file's place, a pipe or a device is named and never read. The manifest itself must be the file its seal, `.MANIFEST.json.bonsaisig`, was made over: its blake2b-512 equals the seal's `file-hash`. Every name is printed quoted, so nothing in the package can add a line to the verdict.

```bash
python3 -I - <<'EOF'
import hashlib, json, os, re, stat
slug = "zensai-san"
for f in ("MANIFEST.json", ".MANIFEST.json.bonsaisig"):
    if not os.path.lexists(f):
        print(f"1 could not run: {f!r} is not in this folder. It is part of the package, and nothing here was checked. A copy or an install that drops names beginning with a dot (a `cp -R <dir>/*`) loses the seal; a listing tool may only hide such names. Run this block where the package is installed, in the folder that holds SKILL.md; if this room must copy the package, copy it whole, hidden files included: cp -a <dir>/. <dest>")
        raise SystemExit(1)
    if os.path.islink(f) or not stat.S_ISREG(os.lstat(f).st_mode):
        print(f"1 could not run: {f!r} is not a plain file here (a link, a folder, a pipe or a device): a finding; nothing was read from it")
        raise SystemExit(1)
try:
    m = json.load(open("MANIFEST.json", encoding="utf-8"))
    s = json.load(open(".MANIFEST.json.bonsaisig", encoding="utf-8"))
    if not isinstance(m, dict) or not isinstance(s, dict) or not isinstance(m.get("files") or {}, dict):
        raise ValueError("MANIFEST.json and its seal must each be a JSON object, and the manifest's files a JSON object")
except Exception as e:
    print(f"1 could not run: {type(e).__name__}: {str(e)!r}")
    raise SystemExit(1)
bad = []
if m.get("slug") != slug:
    bad.append(f"the manifest names {m.get('slug')!r}, not {slug!r}")
if m.get("algorithm") != "sha256":
    bad.append(f"the manifest's algorithm is {m.get('algorithm')!r}, not 'sha256'")
want = {}
for k, v in (m.get("files") or {}).items():
    if k.startswith(slug + "/"):
        want[k[len(slug) + 1 :]] = v
    else:
        bad.append(f"outside the package: {k!r}")
seen = set()
for d, dirs, files in os.walk("."):
    for n in sorted(dirs + files):
        f = os.path.relpath(os.path.join(d, n)).replace(os.sep, "/")
        if os.path.islink(f):
            bad.append(f"a link: {f!r}")
            continue
        if n not in files or f in ("MANIFEST.json", ".MANIFEST.json.bonsaisig"):
            continue
        seen.add(f)
        if not stat.S_ISREG(os.lstat(f).st_mode):
            bad.append(f"not a plain file: {f!r}")
            continue
        if f not in want:
            bad.append(f"not in the manifest: {f!r}")
            continue
        try:
            digest = hashlib.sha256(open(f, "rb").read()).hexdigest()
        except OSError as e:
            bad.append(f"could not read: {f!r} ({type(e).__name__})")
            continue
        if digest != want[f]:
            bad.append(f"changed: {f!r}")
bad += [f"missing: {f!r}" for f in sorted(set(want) - seen)]
try:
    skill = open("SKILL.md", "rb").read().decode("utf-8", "replace") if os.path.isfile("SKILL.md") else ""
except OSError:
    skill = ""
named = re.search(r"^name:\s*[\"']?([^\"'\n]+?)[\"']?\s*$", skill, re.M)
if not named or named.group(1) != slug:
    bad.append(f"SKILL.md does not name {slug!r}")
if hashlib.blake2b(open("MANIFEST.json", "rb").read(), digest_size=64).hexdigest() != s.get("file-hash"):
    bad.append("MANIFEST.json is not the file its seal was made over")
for k, v in (
    ("format", "bonsaisig/2"),
    ("target", "MANIFEST.json"),
    ("signer", "zensai-san"),
    ("role", "owner"),
    ("fingerprint", "038019e65abdc0279870941e6ed942ae"),
):
    if s.get(k) != v:
        bad.append(f"the seal's {k} is {s.get(k)!r}, not {v!r}")
if bad:
    print("1 FAILED: " + "; ".join(bad))
    raise SystemExit(1)
print(f"1 ok: {len(want)} files match the sealed manifest")
EOF
```

## 2. The sealing key vouches for the seal

The key is the file this package carries, `identity/zensai-san-public-key.bin`: block 1 has just shown that it is the file that was sealed with the package, and its fingerprint, the first 32 hex of its sha256, must be `038019e65abdc0279870941e6ed942ae`, the one this page pins. The seal's signature must verify under it. The verifier is the code below: Ed25519 as RFC 8032 writes it, in Python's own integers, nothing imported beyond the standard library, no program started, nothing installed. It says no to a scalar at or above the group order, to a key or nonce that is not canonically encoded or not on the curve, and to a key or nonce of small order. A no is final. The signature covers `bonsai-seal-v2` and a newline, followed by every field of the seal but `signature` as canonical JSON: keys sorted, no whitespace, UTF-8 kept. The block imports `base64`, `hashlib`, `json`, `os` and `stat`: no network module, no address, no request.

At the key's path the block takes a plain file of exactly 32 bytes, or it stops: a link, a folder, a pipe or a device there is a finding, named and never read. Nothing on this page is yours to edit: a block that differs from this page is a finding.

```bash
python3 -I - <<'EOF'
import base64, hashlib, json, os, stat
KEY_FILE = os.path.join("identity", "zensai-san-public-key.bin")  # the key this package carries; block 1 has shown it is the sealed file
try:
    s = json.load(open(".MANIFEST.json.bonsaisig", encoding="utf-8"))
    sig = base64.b64decode(s["signature"], validate=True)
except FileNotFoundError as e:
    print(f"2 could not run: {e.filename!r} is not in this folder: this copy of the package is not whole, or this is not its base directory; block 1 says what to do")
    raise SystemExit(1)
except Exception as e:
    print(f"2 could not run: {type(e).__name__}: {str(e)!r}")
    raise SystemExit(1)
if not os.path.lexists(KEY_FILE) or os.path.islink(KEY_FILE) or not stat.S_ISREG(os.lstat(KEY_FILE).st_mode):
    print(f"2 could not run: {KEY_FILE!r} is not a plain file here (it is missing, or it is a link, a folder, a pipe or a device): a finding; nothing was read from it")
    raise SystemExit(1)
try:
    size = os.path.getsize(KEY_FILE)
    if size != 32:
        print(f"2 FAILED: {KEY_FILE!r} is {size} bytes, not a 32-byte key")
        raise SystemExit(1)
    key = open(KEY_FILE, "rb").read(33)
except OSError as e:
    print(f"2 could not run: {KEY_FILE!r} could not be read ({type(e).__name__}: {str(e)!r})")
    raise SystemExit(1)
fp = hashlib.sha256(key).hexdigest()[:32]
if len(key) != 32 or fp != "038019e65abdc0279870941e6ed942ae":
    print(f"2 FAILED: the key this package carries has fingerprint {fp!r}, not '038019e65abdc0279870941e6ed942ae'")
    raise SystemExit(1)
payload = (
    "bonsai-seal-v2\n"
    + json.dumps({k: v for k, v in s.items() if k != "signature"}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
).encode("utf-8")

# Ed25519, verify only, as RFC 8032 writes it (section 5.1), in Python's own integers. No secret is ever here.
p = 2**255 - 19  # the field
d = -121665 * pow(121666, p - 2, p) % p  # the curve: -x^2 + y^2 = 1 + d x^2 y^2
L = 2**252 + 27742317777372353535851937790883648493  # the order of the base point B
ONE = (0, 1, 1, 0)  # the identity, in extended coordinates (X, Y, Z, T)

def decode_point(b):
    """Section 5.1.3: 32 bytes to a point, or None wherever the RFC says decoding fails."""
    y = int.from_bytes(b, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= p:  # no: not canonically encoded (a y at or above p)
        return None
    x2 = (y * y - 1) * pow(d * y * y + 1, p - 2, p) % p
    x = pow(x2, (p + 3) // 8, p)
    if (x * x - x2) % p:
        x = x * pow(2, (p - 1) // 4, p) % p
    if (x * x - x2) % p:  # no: not on the curve (x^2 has no square root)
        return None
    if x == 0 and sign:  # no: x = 0 with the sign bit set
        return None
    if x & 1 != sign:
        x = p - x
    return (x, y, 1, x * y % p)

def point_add(P, Q):
    """Section 5.1.4: the addition law in extended coordinates."""
    A, B_ = (P[1] - P[0]) * (Q[1] - Q[0]) % p, (P[1] + P[0]) * (Q[1] + Q[0]) % p
    C, D = 2 * P[3] * Q[3] * d % p, 2 * P[2] * Q[2] % p
    E, F, G, H = B_ - A, D - C, D + C, B_ + A
    return (E * F % p, G * H % p, F * G % p, E * H % p)

def scalar_mul(k, P):
    """k times P, by doubling and adding, k read from its lowest bit up."""
    Q = ONE
    while k:
        if k & 1:
            Q = point_add(Q, P)
        P, k = point_add(P, P), k >> 1
    return Q

def same_point(P, Q):
    """Both coordinates compared, in projective form: X1 Z2 = X2 Z1 and Y1 Z2 = Y2 Z1."""
    return (P[0] * Q[2] - Q[0] * P[2]) % p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % p == 0

def small_order(P):
    """8 P is the identity: a point of the torsion subgroup, under which a signature could be forged."""
    return same_point(scalar_mul(8, P), ONE)

B = decode_point((4 * pow(5, p - 2, p) % p).to_bytes(32, "little"))  # the base point: y = 4/5, x even

def verify(key, msg, sig):
    """Section 5.1.7, cofactorless: s B == R + h A, with h = SHA-512(R || A || msg) mod L. A no is final."""
    if len(key) != 32 or len(sig) != 64:  # no: a key or signature of the wrong length, before anything is decoded
        return False
    A, R, s = decode_point(key), decode_point(sig[:32]), int.from_bytes(sig[32:], "little")
    if A is None or R is None:  # no: a key or nonce that does not decode
        return False
    if s >= L:  # no: a scalar at or above the group order
        return False
    if small_order(A) or small_order(R):  # no: a key or nonce of small order
        return False
    h = int.from_bytes(hashlib.sha512(sig[:32] + key + msg).digest(), "little") % L
    return same_point(scalar_mul(s, B), point_add(R, scalar_mul(h, A)))

ok = verify(key, payload, sig)
print(f"2 ok: sealed by zensai-san as owner, key {fp}, the key this package carries, held to the fingerprint this page pins" if ok else "2 FAILED: the signature does not verify under that key")
raise SystemExit(0 if ok else 1)
EOF
```

## When the checks say ok

Say nothing about it, and go on. A check is spoken of only when it fails.

What the check proves: these files are intact, and sealed by the key with the fingerprint above. It tells you that, not who made this copy, and not whether that key still stands: the check asks no one, so a key withdrawn after this package was built is not seen here. Anyone can re-seal a copy with a key of their own and rewrite this page to match. So the second witness stands outside the package: anyone can compare `038019e65abdc0279870941e6ed942ae` with the garden's own record, in their own browser, at <https://bon-sai.garden/verify/?fp=038019e65abdc0279870941e6ed942ae>.
