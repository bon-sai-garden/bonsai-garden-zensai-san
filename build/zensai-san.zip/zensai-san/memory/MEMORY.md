---
title: "zensai-san — memory index (empty in the shintai; the memory lives only in a folder the person gives, never in this package)"
type: memory-index
tended-by: zensai-san
---
